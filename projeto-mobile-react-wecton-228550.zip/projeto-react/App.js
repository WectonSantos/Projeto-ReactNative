// WECTON SANTOS
// R.A 228550

import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { UserProvider } from './UserContext';
import Home from './telas/Home';
import Login from './telas/Login';
import Cadastro from './telas/Cadastro';
import Catalogo from './telas/Catalogo';
import Compra from './telas/Compra';
import Compras from './telas/Compras';

const Stack = createStackNavigator();

export default function App() {
  return (
    <UserProvider>
      <NavigationContainer>
        <Stack.Navigator initialRouteName="Home">
          <Stack.Screen name="Home" component={Home} />
          <Stack.Screen name="Login" component={Login} />
          <Stack.Screen name="Cadastro" component={Cadastro} />
          <Stack.Screen name="Catalogo" component={Catalogo} />
          <Stack.Screen name="Compra" component={Compra} />
          <Stack.Screen name="Compras" component={Compras} />
        </Stack.Navigator>
      </NavigationContainer>
    </UserProvider>
  );
}
