import React, { createContext, useState, useContext } from 'react';

const UserContext = createContext();

export const UserProvider = ({ children }) => {
  const [usuarioLogado, setUsuarioLogado] = useState(null);
  const [usuarios, setUsuarios] = useState([
    ["Joao", "abc1r1"],
    ["Jose", "fy63u*"],
    ["MaLu", "th678"],
    ["Luck", "lsji48se"],
    ["Hansol", "stwr478"],
    ["Wecton", "123"],
    ["Ferrara", "9520"],
    ['Raquel', "unisanta2024"]
  ]);
  const [compras, setCompras] = useState([]); 

  const adicionarUsuario = (nome, senha) => {
    setUsuarios([...usuarios, [nome, senha]]);
  };

  const login = (username) => {
    setUsuarioLogado(username);
  };

  const logout = () => {
    setUsuarioLogado(null);
  };

  const adicionarCompra = (filme) => {
    setCompras([...compras, filme]); 
  };

  return (
    <UserContext.Provider value={{
      usuarioLogado,
      login,
      logout,
      usuarios,
      adicionarUsuario,
      compras,
      adicionarCompra
    }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUserContext = () => {
  return useContext(UserContext);
};
