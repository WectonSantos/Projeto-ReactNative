import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#141414',
    padding: 20,
  },
  botao: {
    backgroundColor: '#e50914',
    padding: 15,
    marginTop: 10,
    alignItems: 'center',
    borderRadius: 5,
  },
  botaoTexto: {
    color: '#fff',
    backgroundColor: '#e50914',
    fontSize: 16,
    alignItems: 'center',
    borderRadius: 5,
  },
  input: {
    backgroundColor: '#333',
    padding: 10,
    marginVertical: 5,
    borderRadius: 5,
    color: '#fff',
  },
  titulo: {
    color: '#fff',
    fontSize: 24,
    textAlign: 'center',
    marginBottom: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 40,
    paddingBottom: 10,
    borderBottomWidth: 1,
    borderColor: '#333',
  },
  logo: {
    width: 120,
    height: 40,
    resizeMode: 'contain',
  },
  username: {
    color: '#fff',
    fontSize: 16,
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  cardFilme: {
    marginBottom: 20,
  },
  filmeImagem: {
    width: '100%',
    height: 400,
    resizeMode: 'cover',
    borderRadius: 10,
  },
  filmeTitulo: {
    color: '#fff',
    fontSize: 18,
    textAlign: 'center',
    marginTop: 10,
  },
  
});
