import React from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';
import estilo from './estilos';

const FilmeCard = ({ filme, onSelect }) => (
  <View style={estilo.cardFilme}>
    <Image source={{ uri: filme.imagem }} style={estilo.filmeImagem} />
    <Text style={estilo.filmeTitulo}>{filme.titulo}</Text>
    <TouchableOpacity onPress={() => onSelect(filme)} style={estilo.botao}>
      <Text style={estilo.botaoTexto}>Alugar</Text>
    </TouchableOpacity>
  </View>
);

export default FilmeCard;
