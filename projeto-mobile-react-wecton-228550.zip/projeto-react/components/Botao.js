import React from 'react';
import { TouchableOpacity, Text } from 'react-native';
import estilo from './estilos';

const Botao = ({ titulo, onPress, style }) => (
  <TouchableOpacity style={[estilo.botao, style]} onPress={onPress}>
    <Text style={estilo.botaoTexto}>{titulo}</Text>
  </TouchableOpacity>
);

export default Botao;
