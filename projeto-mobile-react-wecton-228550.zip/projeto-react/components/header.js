import React, { useEffect } from 'react';
import { View, Text, TouchableOpacity, Image } from 'react-native';
import { useUserContext } from '../UserContext'; 
import estilo from './estilos';

const Header = ({ onLogout, onNavigateToCompras }) => {
  const { usuarioLogado } = useUserContext();

  useEffect(() => {
    console.log("Usuário logado:", usuarioLogado);
  }, [usuarioLogado]);

  return (
    <View style={estilo.header}>
      <Image
        source={require('../images/wectonflix.png')}
        style={estilo.logo}
      />
      {usuarioLogado && (
        <View style={estilo.headerRight}>
          <Text style={estilo.username}>| {usuarioLogado}</Text>
          <TouchableOpacity onPress={onLogout}>
            <Text style={{color:'white'}}> | Sair | </Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={onNavigateToCompras}>
            <Text style={estilo.botaoTexto}>Ir para Compras</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
};

export default Header;
