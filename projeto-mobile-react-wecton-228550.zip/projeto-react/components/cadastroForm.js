import React, { useState } from 'react';
import { View, TextInput, TouchableOpacity, Text } from 'react-native';
import estilo from './estilos.js';

const CadastroForm = ({ onRegister }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleRegister = () => {
    if (username && password) {
      onRegister(username, password);
    }
  };

  return (
    <View style={estilo.form}>
      <TextInput
        style={estilo.input}
        placeholder="Usuário"
        value={username}
        onChangeText={setUsername}
      />
      <TextInput
        style={estilo.input}
        placeholder="Senha"
        value={password}
        secureTextEntry
        onChangeText={setPassword}
      />
      <TouchableOpacity onPress={handleRegister}>
        <Text style={estilo.button}>Cadastrar</Text>
      </TouchableOpacity>
    </View>
  );
};

export default CadastroForm;
