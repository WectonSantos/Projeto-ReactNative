import React, { useState } from 'react';
import { View, TextInput, TouchableOpacity, Text } from 'react-native';
import estilo from './estilos.js';
const users = [
  ["Joao", "abc1r1"],
  ["Jose", "fy63u*"],
  ["MaLu", "th678"],
  ["Luck", "lsji48se"],
  ["Hansol", "stwr478"]
];

const LoginForm = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = () => {
    const user = users.find(([user, pass]) => user === username && pass === password);
    if (user) {
      onLogin(username);
    } else {
      setError('Usuário ou senha inválidos');
    }
  };

  return (
    <View style={estilo.form}>
      <TextInput
        style={estilo.input}
        placeholder="Usuário"
        value={username}
        onChangeText={setUsername}
      />
      <TextInput
        style={estilo.input}
        placeholder="Senha"
        value={password}
        secureTextEntry
        onChangeText={setPassword}
      />
      {error ? <Text style={estilo.error}>{error}</Text> : null}
      <TouchableOpacity onPress={handleLogin}>
        <Text style={estilo.button}>Login</Text>
      </TouchableOpacity>
    </View>
  );
};

export default LoginForm;
