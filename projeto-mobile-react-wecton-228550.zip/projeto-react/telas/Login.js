import React, { useState } from 'react';
import { View, TextInput, Text, TouchableOpacity } from 'react-native';
import { useUserContext } from '../UserContext';  
import estilo from '../components/estilos';

const Login = ({ navigation }) => {
  const { usuarios, login } = useUserContext();  
  const [usuario, setUsuario] = useState('');
  const [senha, setSenha] = useState('');

  const handleLogin = () => {
    const usuarioLogado = usuarios.find(
      (u) => u[0] === usuario && u[1] === senha
    );
    if (usuarioLogado) {
      login(usuario);
      navigation.navigate('Catalogo');
    } else {
      alert('Usuário ou senha inválidos');
    }
  };

  return (
  <View style={{flex: 1, backgroundColor: '#141414', padding: 20, justifyContent: 'center'}}>
      <Text style={estilo.titulo}>Login</Text>
      <TextInput
        style={estilo.input}
        placeholder="Usuário"
        value={usuario}
        onChangeText={setUsuario}
      />
      <TextInput
        style={estilo.input}
        placeholder="Senha"
        secureTextEntry
        value={senha}
        onChangeText={setSenha}
      />
      <TouchableOpacity style={estilo.botao} onPress={handleLogin}>
        <Text style={estilo.botaoTexto}>Entrar</Text>
      </TouchableOpacity>
    </View>
  );
};

export default Login;
