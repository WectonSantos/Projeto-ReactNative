import React, { useState } from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';
import estilo from '../components/estilos';
import { useUserContext } from '../UserContext';

const Compra = ({ route, navigation }) => {
  const { filme } = route.params;
  const { adicionarCompra } = useUserContext(); 

  const handleComprar = () => {
    adicionarCompra(filme); 
    navigation.navigate('Compras'); 
  };

  return (
    <View style={estilo.container}>
      <Image source={{ uri: filme.imagem }} style={estilo.filmeImagem} />
      <Text style={estilo.filmeTitulo}>{filme.titulo}</Text>
      <TouchableOpacity onPress={handleComprar} style={estilo.botao}>
        <Text style={estilo.botaoTexto}>Confirmar Compra</Text>
      </TouchableOpacity>
    </View>
  );
};

export default Compra;
