import React from 'react';
import { View, Text, Image } from 'react-native';
import Botao from '../components/Botao';
import estilo from '../components/estilos';

const Home = ({ navigation }) => (
  <View style={{flex: 1, backgroundColor: '#141414', padding: 20, justifyContent: 'center'}}>
    <Image
      source={require('../images/wectonflix.png')} 
      style={estilo.logo}
    />
    <Text style={estilo.titulo}>Bem-vindo ao Wectonflix</Text>
    <Botao titulo="Login" onPress={() => navigation.navigate('Login')} />
    <Botao titulo="Cadastro" onPress={() => navigation.navigate('Cadastro')} />
  </View>
);

export default Home;
