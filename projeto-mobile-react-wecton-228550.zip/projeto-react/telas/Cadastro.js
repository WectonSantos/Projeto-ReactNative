import React, { useState } from 'react';
import { View, TextInput, Alert } from 'react-native';
import { useUserContext } from '../UserContext';
import Botao from '../components/Botao';
import estilo from '../components/estilos';

const Cadastro = ({ navigation }) => {
  const [nome, setNome] = useState('');
  const [senha, setSenha] = useState('');
  const { usuarios, adicionarUsuario } = useUserContext();

  const handleCadastro = () => {
    if (nome && senha) {
      const usuarioExistente = usuarios.find(u => u[0] === nome);
      if (usuarioExistente) {
        Alert.alert('Erro', 'Nome de usuário já existe!');
      } else {
        adicionarUsuario(nome, senha);
        Alert.alert('Sucesso', 'Cadastro realizado com sucesso!');
        navigation.navigate('Login');
      }
    } else {
      Alert.alert('Erro', 'Preencha todos os campos!');
    }
  };

  return (
  <View style={{flex: 1, backgroundColor: '#141414', padding: 20, justifyContent: 'center'}}>
      <TextInput
        style={estilo.input}
        placeholder="Nome"
        value={nome}
        onChangeText={setNome}
      />
      <TextInput
        style={estilo.input}
        placeholder="Senha"
        value={senha}
        onChangeText={setSenha}
        secureTextEntry
      />
      <Botao titulo="Cadastrar" onPress={handleCadastro} />
    </View>
  );
};

export default Cadastro;
