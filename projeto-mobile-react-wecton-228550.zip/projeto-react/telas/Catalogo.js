import React, { useState } from 'react';
import { View, TextInput, ScrollView, Text } from 'react-native';
import Header from '../components/header';
import FilmeCard from '../components/cartaoFilme'; 
import estilo from '../components/estilos'; 

const filmes = [
  { id: 0, titulo: 'Forrest Gump', imagem: 'https://www.justwatch.com/images/poster/301039564/s718/forrest-gump-o-contador-de-historias.jpg' },
  { id: 1, titulo: 'O Segredo de Seus Olhos', imagem: 'https://upload.wikimedia.org/wikipedia/pt/thumb/5/5f/Segredo_Seus_Olhos.jpg/225px-Segredo_Seus_Olhos.jpg' },
  { id: 2, titulo: 'Um Sonho de Liberdade', imagem: 'https://br.web.img2.acsta.net/medias/nmedia/18/90/16/48/20083748.jpg' },
  { id: 3, titulo: 'The Flash', imagem: 'https://br.web.img3.acsta.net/pictures/23/06/14/20/18/3063969.jpg' },
  { id: 4, titulo: 'A Lista de Schindler', imagem: 'https://upload.wikimedia.org/wikipedia/pt/1/1d/SchindlerPoster.jpg' },
  { id: 5, titulo: 'Cidade de Deus', imagem: 'https://upload.wikimedia.org/wikipedia/pt/thumb/1/10/CidadedeDeus.jpg/250px-CidadedeDeus.jpg' },
  { id: 6, titulo: 'O Lobo de Wall Street', imagem: 'https://br.web.img2.acsta.net/pictures/13/12/30/18/11/111145.jpg' },
  { id: 7, titulo: 'Brilho Eterno de Uma Mente sem Lembranças', imagem: 'https://upload.wikimedia.org/wikipedia/pt/a/af/Eternal_Sunshine_of_the_Spotless_Mind.jpg' },
  { id: 8, titulo: 'O Iluminado', imagem: 'https://br.web.img3.acsta.net/r_1280_720/pictures/23/08/24/21/28/4212500.jpg' },
  { id: 9, titulo: 'O Poderoso Chefão', imagem: 'https://uauposters.com.br/media/catalog/product/5/1/518020201013-uau-posters-filmes-mafia-the-godfather-o-poderoso-chefao.jpg' },
  { id: 10, titulo: 'Garota Exemplar', imagem: 'https://br.web.img3.acsta.net/pictures/14/08/20/21/11/442051.jpg' },
  { id: 11, titulo: 'Seven', imagem: 'https://m.media-amazon.com/images/I/61OsWbR83TL._AC_UF894,1000_QL80_.jpg' },
  { id: 12, titulo: 'O Silêncio dos Inocentes', imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRUNCQTSBEGYEfQ3vNtE58c8D_s4u5PJNyUvw&s' },
  { id: 13, titulo: 'Kill Bill', imagem: 'https://br.web.img2.acsta.net/medias/nmedia/18/89/48/24/20122126.jpg' },
  { id: 14, titulo: 'Ilha do Medo', imagem: 'https://assets.cinebelasartes.com.br/wp-content/uploads/2016/03/ILHA-DO-MEDO.jpg' },
  { id: 15, titulo: 'Taxi Driver', imagem: 'https://upload.wikimedia.org/wikipedia/pt/3/33/Taxi_Driver_%281976_film_poster%29.jpg' },
  { id: 16, titulo: 'A Origem', imagem: 'https://br.web.img3.acsta.net/medias/nmedia/18/87/32/31/20028688.jpg' },
  { id: 17, titulo: 'Coringa', imagem: 'https://cdn.awsli.com.br/600x700/1610/1610163/produto/177680469/poster-joker-coringa-d-15840799.jpg' },
  { id: 18, titulo: 'Interestelar', imagem: 'https://br.web.img3.acsta.net/pictures/14/10/31/20/39/476171.jpg' },
  { id: 19, titulo: 'O Cavaleiro das Trevas', imagem: 'https://br.web.img3.acsta.net/medias/nmedia/18/86/98/32/19870786.jpg' },
  { id: 20, titulo: 'As Vantagens de Ser Invisível', imagem: 'https://br.web.img3.acsta.net/medias/nmedia/18/90/78/52/20295598.jpg' },
  { id: 21, titulo: 'Donnie Darko', imagem: 'https://upload.wikimedia.org/wikipedia/pt/5/58/Donnie_Darko.jpg' },
  { id: 22, titulo: 'De Volta Para o Futuro', imagem: 'https://br.web.img3.acsta.net/medias/nmedia/18/90/95/62/20122008.jpg' },
  { id: 23, titulo: 'GoodFellas', imagem: 'https://m.media-amazon.com/images/M/MV5BN2E5NzI2ZGMtY2VjNi00YTRjLWI1MDUtZGY5OWU1MWJjZjRjXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg' },
  { id: 24, titulo: 'Os Suspeitos', imagem: 'https://upload.wikimedia.org/wikipedia/pt/c/c4/Prisoners_p%C3%B4ster.jpg' },
  { id: 25, titulo: 'Avatar', imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR4CmPkVk6RRcXK4sUrJacnL0396YP1cdFE8A&s' },
  { id: 26, titulo: 'Prenda-me se for Capaz', imagem: 'https://br.web.img3.acsta.net/pictures/210/100/21010048_20130603234956231.jpg' },
  { id: 27, titulo: 'Homem-Aranha', imagem: 'https://upload.wikimedia.org/wikipedia/pt/1/14/Spide-Man_Poster.jpg' },
  { id: 28, titulo: 'Superbad', imagem: 'https://m.media-amazon.com/images/I/61nHD0I77KL.jpg' },
  { id: 29, titulo: 'Laranja Mecânica', imagem: 'https://upload.wikimedia.org/wikipedia/pt/7/73/A_Clockwork_Orange_%281971%29.png' },
  { id: 30, titulo: 'Homem-Aranha 2', imagem: 'https://br.web.img2.acsta.net/pictures/210/544/21054460_2013103118041242.jpg' },
  { id: 31, titulo: 'Psicose', imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRPgv6t7kCvIvo47FsNSU9A6cscT_boXXlzLPOQX6WlzUlFnnnK9Zq4ts-sAOLGtuI_ahg&usqp=CAU' },
  { id: 32, titulo: 'The Prestige', imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR1l1q9BgINmfsSZ45XMOS5nspqUMn8RLtR6Q&s' },
  { id: 33, titulo: 'Bohemian Rhapsody', imagem: 'https://m.media-amazon.com/images/I/71kuEWe9PYL._AC_UF894,1000_QL80_.jpg' },
  { id: 34, titulo: 'Scarface', imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRZ2cs7dbasgeNeO4pqNwvkZwViYsWoBbdD_Q&s' },
  { id: 35, titulo: 'Curtindo a Vida Adoidado', imagem: 'https://assets.cinebelasartes.com.br/wp-content/uploads/2023/05/cartaz-curtindo-a-vida-adoidado-min.jpg' },
  { id: 36, titulo: 'O Resgate do Soldado Ryan', imagem: 'https://upload.wikimedia.org/wikipedia/pt/a/ac/Saving_Private_Ryan_poster.jpg' },
  { id: 37, titulo: 'O Sexto Sentido', imagem: 'https://br.web.img2.acsta.net/medias/nmedia/18/90/53/94/20101506.jpg' },
  { id: 38, titulo: 'When Harry Met Sally', imagem: 'https://upload.wikimedia.org/wikipedia/pt/8/8a/When_Harry_Met_Sally....jpg' },
  { id: 39, titulo: 'Um Estranho no Ninho', imagem: 'https://upload.wikimedia.org/wikipedia/pt/f/fb/CuckoosNest.jpg' },
  { id: 40, titulo: 'Fogo contra Fogo', imagem: 'https://br.web.img3.acsta.net/medias/nmedia/18/93/46/52/20258492.jpg' },
  { id: 41, titulo: 'A Espera de Um Milagre', imagem: 'https://br.web.img3.acsta.net/c_310_420/medias/nmedia/18/91/66/66/20156966.jpg' },
  { id: 42, titulo: 'O Jogo da Imitação', imagem: 'https://upload.wikimedia.org/wikipedia/pt/1/1a/O_Jogo_da_Imita%C3%A7%C3%A3o.jpg' },
  { id: 43, titulo: 'Casablanca', imagem: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b3/CasablancaPoster-Gold.jpg/245px-CasablancaPoster-Gold.jpg' },
  { id: 44, titulo: 'Green Book', imagem: 'https://br.web.img2.acsta.net/pictures/18/08/15/13/09/1891759.jpg' },
  { id: 45, titulo: 'Rocky', imagem: 'https://upload.wikimedia.org/wikipedia/pt/thumb/1/18/Rocky_poster.jpg/230px-Rocky_poster.jpg' },
  { id: 46, titulo: 'Até o Último Homem', imagem: 'https://br.web.img3.acsta.net/pictures/16/11/21/15/29/457312.jpg' },
  { id: 47, titulo: '12 Anos de Escravidão', imagem: 'https://br.web.img2.acsta.net/pictures/14/03/10/18/29/032627.jpg' },
  { id: 48, titulo: 'A Outra História Americana', imagem: 'https://upload.wikimedia.org/wikipedia/pt/thumb/f/f1/American_History_X.jpg/200px-American_History_X.jpg' },
  { id: 49, titulo: 'A Procura da Felicidade', imagem: 'https://br.web.img2.acsta.net/medias/nmedia/18/86/96/34/20028591.jpg' },
  { id: 50, titulo: 'A Vida é Bela', imagem: 'https://br.web.img3.acsta.net/medias/nmedia/18/87/87/63/19962446.jpg' },
  { id: 51, titulo: 'Náufrago', imagem: 'https://br.web.img3.acsta.net/medias/nmedia/18/87/27/38/19873802.jpg' },
  { id: 52, titulo: 'Gigante de Ferro', imagem: 'https://upload.wikimedia.org/wikipedia/pt/6/6c/TheIronGiant-P%C3%B4ster.jpg' },
  { id: 53, titulo: 'Clube de Compras Dallas', imagem: 'https://br.web.img3.acsta.net/pictures/14/01/22/16/21/581350.jpg' },
  { id: 54, titulo: 'A Teoria de Tudo', imagem: 'https://br.web.img3.acsta.net/pictures/14/12/02/22/15/327211.jpg' },
  { id: 55, titulo: 'Intocáveis', imagem: 'https://upload.wikimedia.org/wikipedia/pt/d/d6/Intouchables_cartaz.jpg' },
  { id: 56, titulo: 'Liga da Justiça de Zack Snyder', imagem: 'https://musicart.xboxlive.com/7/d5a25100-0000-0000-0000-000000000002/504/image.jpg?w=1920&h=1080' },
  { id: 57, titulo: 'Uma Mente Brilhante', imagem: 'https://upload.wikimedia.org/wikipedia/pt/b/b1/UmaMenteBrilhante.jpg' },
  { id: 58, titulo: 'Coda', imagem: 'https://upload.wikimedia.org/wikipedia/pt/e/eb/Coda_2021.jpg' },
  { id: 59, titulo: 'O Menino de Pijama Listrado', imagem: 'https://br.web.img2.acsta.net/medias/nmedia/18/87/82/34/20028625.jpg' },
  { id: 60, titulo: 'Efeito Borboleta', imagem: 'https://upload.wikimedia.org/wikipedia/pt/4/43/Butterflyeffect_poster.jpg' },
  { id: 61, titulo: 'Projeto X', imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR-q4EIoFQjeOoWe-SJ33KCWl3vbWc2p1NGvg&s' },
  { id: 62, titulo: 'O Terminal', imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQeC45GPWUeOKrn9uGR057KzWEnQ3yzmf5wRA&s' },
  { id: 63, titulo: 'Rain Man', imagem: 'https://br.web.img3.acsta.net/medias/nmedia/18/87/18/19/19872843.jpg' },
  { id: 64, titulo: 'The Machinist', imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQTXefJqy9LmGBNtFoCevUKeuPLDwEKB6j-ZQ&s' },
  { id: 65, titulo: 'Creed II', imagem: 'https://m.media-amazon.com/images/I/915Mm6Ut9HL._AC_UF894,1000_QL80_.jpg' },
  { id: 66, titulo: 'Perfume de Mulher', imagem: 'https://upload.wikimedia.org/wikipedia/pt/9/91/Scent_of_a_Woman.jpg' },
  { id: 67, titulo: 'Rambo', imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRU7AEcpBUdoUyw7OATs-hgWYCcojndtk0O5w&s' },
  { id: 68, titulo: 'Kramer vs Kramer', imagem: 'https://www.justwatch.com/images/poster/301792184/s718/kramer-vs-kramer.jpg' },
  { id: 69, titulo: 'Dragão Vermelho', imagem: 'https://br.web.img3.acsta.net/medias/nmedia/18/91/11/62/20130326.jpg' },
  { id: 70, titulo: 'Tropa de Elite', imagem: 'https://upload.wikimedia.org/wikipedia/pt/thumb/2/2a/TropaDeElitePoster.jpg/250px-TropaDeElitePoster.jpg' },
  { id: 71, titulo: 'Milagre na Cela 7', imagem: 'https://br.web.img3.acsta.net/pictures/19/10/08/15/52/1926679.jpg' },
  { id: 72, titulo: 'Stallone Cobra', imagem: 'https://upload.wikimedia.org/wikipedia/pt/e/eb/Cobra_%281986%29_Poster.jpg' },
  { id: 73, titulo: 'Falcão', imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSSKIFUtu6TUYSit4mZXU9LhWmn3CIyKpb5-g&s' },
];

const Catalogo = ({ navigation }) => {
  const [pesquisa, setPesquisa] = useState('');

  const handleSearch = () => {
    return filmes.filter(filme =>
      filme.titulo.toLowerCase().includes(pesquisa.toLowerCase())
    );
  };

  const navigateToCompras = () => {
    navigation.navigate('Compras');
  };

  const handleLogout = () => {
    navigation.navigate('Login'); 
  };

  return (
    <View style={estilo.container}>
      <Header onLogout={handleLogout} onNavigateToCompras={navigateToCompras} />
      <TextInput
        style={estilo.input}
        placeholder="Pesquisar Filmes"
        value={pesquisa}
        onChangeText={setPesquisa}
      />
      <ScrollView>
        {handleSearch().map(filme => (
          <FilmeCard
            key={filme.id}
            filme={filme}
            onSelect={() => navigation.navigate('Compra', { filme })}
          />
        ))}
      </ScrollView>
    </View>
  );
};

export default Catalogo;
