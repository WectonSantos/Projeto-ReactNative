import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, Image } from 'react-native';
import { useUserContext } from '../UserContext';
import Header from '../components/header'; 
import estilo from '../components/estilos'; 

const Compras = ({ navigation }) => {
  const { compras } = useUserContext();

  return (
    <View style={estilo.container}>
      <Header onLogout={() => navigation.navigate('Login')} />
      <Text style={estilo.titulo}>Histórico de Compras</Text>
      <ScrollView>
        {compras.map((compra, index) => (
          <View key={index} style={estilo.cardFilme}>
            <Image source={{ uri: compra.imagem }} style={estilo.filmeImagem} />
            <Text style={estilo.filmeTitulo}>{compra.titulo}</Text>
          </View>
        ))}
      </ScrollView>
      <TouchableOpacity onPress={() => navigation.navigate('Catalogo')} style={estilo.botao}>
        <Text style={estilo.botaoTexto}>Voltar ao Catálogo</Text>
      </TouchableOpacity>
    </View>
  );
};

export default Compras;
